<?php
class Whizzie {

    public function __construct() {
        $this->init();
    }

    public function init() {
        $this->pastry_shop_setup_theme_mods();
    }

    public function pastry_shop_setup_theme_mods() {
        $pastry_shop_options = get_theme_mod('theme_options', []);
        $pastry_shop_options['pastry_shop_header_top_button_text'] = 'Online Book';
        $pastry_shop_options['pastry_shop_header_top_button_link'] = '#';
        $pastry_shop_options['pastry_shop_quote_button_link'] = '#';
        set_theme_mod('theme_options', $pastry_shop_options);

        /* Create Menu */
            $pastry_shop_menuname  = 'Primary Menu';
            $pastry_shop_location  = 'primary-menu';

            $pastry_shop_menu = wp_get_nav_menu_object( $pastry_shop_menuname );

            if ( ! $pastry_shop_menu ) {
            $pastry_shop_menu_id = wp_create_nav_menu( $pastry_shop_menuname );

           // Home Page 
			wp_update_nav_menu_item( $pastry_shop_menu_id, 0, array(
				'menu-item-title'     => __( 'Home', 'pastry-shop' ),
				'menu-item-url'       => home_url( '/' ),
				'menu-item-type'      => 'custom',
				'menu-item-status'    => 'publish',
			) );

			// About Us Page 
			$pastry_shop_about_id = wp_insert_post( array(
			'post_type'   => 'page',
			'post_content' => 'We are committed to providing reliable, professional, and result-oriented solutions tailored to meet individual needs. Our goal is to empower people with the right guidance, knowledge, and support to help them make informed decisions for a better future. <br><br> Our mission is to deliver high-quality services with honesty, transparency, and dedication. We focus on understanding client requirements and offering practical solutions that create long-term value. <br><br> With a client-centric approach, experienced professionals, and a commitment to excellence, we ensure every individual receives the attention and guidance they deserve. We believe in building trust through quality service and consistent results.',
			'post_title'  => 'About Us',
			'post_status' => 'publish',
			) );

			if ( $pastry_shop_about_id ) {
			wp_update_nav_menu_item( $pastry_shop_menu_id, 0, array(
			'menu-item-title'     => 'About Us',
			'menu-item-object'    => 'page',
			'menu-item-object-id' => $pastry_shop_about_id,
			'menu-item-type'      => 'post_type',
			'menu-item-status'    => 'publish',
			) );
			}

			// Pages Page 
			$pastry_shop_about_id = wp_insert_post( array(
			'post_type'   => 'page',
			'post_content' => 'We are committed to providing reliable, professional, and result-oriented solutions tailored to meet individual needs. Our goal is to empower people with the right guidance, knowledge, and support to help them make informed decisions for a better future. <br><br> Our mission is to deliver high-quality services with honesty, transparency, and dedication. We focus on understanding client requirements and offering practical solutions that create long-term value. <br><br> With a client-centric approach, experienced professionals, and a commitment to excellence, we ensure every individual receives the attention and guidance they deserve. We believe in building trust through quality service and consistent results.',
			'post_title'  => 'Pages',
			'post_status' => 'publish',
			) );

			if ( $pastry_shop_about_id ) {
			wp_update_nav_menu_item( $pastry_shop_menu_id, 0, array(
			'menu-item-title'     => 'Pages',
			'menu-item-object'    => 'page',
			'menu-item-object-id' => $pastry_shop_about_id,
			'menu-item-type'      => 'post_type',
			'menu-item-status'    => 'publish',
			) );
			}

            // Create Blog Page
                $pastry_shop_blog_page_title = 'Blog';

                $pastry_shop_blog_page_query = new WP_Query(array(
                    'post_type'      => 'page',
                    'name'           => sanitize_title($pastry_shop_blog_page_title),
                    'post_status'    => 'publish',
                    'posts_per_page' => 1
                ) );
                
                if (!$pastry_shop_blog_page_query->hae_posts()) {
                    $pastry_shop_blog_page = array(
                        'post_type'   => 'page',
                        'post_title'  => $pastry_shop_blog_page_title,
                        'post_status' => 'publish',
                        'post_author' => 1,
                    );
                    $pastry_shop_blog_page_id = wp_insert_post($pastry_shop_blog_page);
                    update_option('page_for_posts', $pastry_shop_blog_page_id);

                    wp_update_nav_menu_item($pastry_shop_menu_id, 0, array(
                        'menu-item-title'      => __('Blog', 'pastry-shop'),
                        'menu-item-url'        => get_permalink($pastry_shop_blog_page_id),
                        'menu-item-status'     => 'publish',
                        'menu-item-object-id'  => $pastry_shop_blog_page_id,
                        'menu-item-object'     => 'page',
                        'menu-item-type'       => 'post_type',
                    ) );
                    }
            // Contact Us Page 
			$pastry_shop_about_id = wp_insert_post( array(
			'post_type'   => 'page',
			'post_content' => 'We are committed to providing reliable, professional, and result-oriented solutions tailored to meet individual needs. Our goal is to empower people with the right guidance, knowledge, and support to help them make informed decisions for a better future. <br><br> Our mission is to deliver high-quality services with honesty, transparency, and dedication. We focus on understanding client requirements and offering practical solutions that create long-term value. <br><br> With a client-centric approach, experienced professionals, and a commitment to excellence, we ensure every individual receives the attention and guidance they deserve. We believe in building trust through quality service and consistent results.',
			'post_title'  => 'Contact Us',
			'post_status' => 'publish',
			) );

			if ( $pastry_shop_about_id ) {
			wp_update_nav_menu_item( $pastry_shop_menu_id, 0, array(
			'menu-item-title'     => 'Contact Us',
			'menu-item-object'    => 'page',
			'menu-item-object-id' => $pastry_shop_about_id,
			'menu-item-type'      => 'post_type',
			'menu-item-status'    => 'publish',
			) );
			}
            
			/* Assign Menu Location */
			$pastry_shop_locations = get_theme_mod( 'nav_menu_locations', array() );
			$pastry_shop_locations[ $pastry_shop_location ] = $pastry_shop_menu_id;
			set_theme_mod( 'nav_menu_locations', $pastry_shop_locations );
		}
    }
}