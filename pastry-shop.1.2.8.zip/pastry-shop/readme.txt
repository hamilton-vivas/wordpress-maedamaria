=== Pastry Shop ===

Contributors: mizanthemes
Tags: one-column, two-columns, three-columns, four-columns, left-sidebar, right-sidebar, custom-background, custom-menu, custom-header, featured-images, sticky-post, full-width-template, rtl-language-support, translation-ready, theme-options, threaded-comments, footer-widgets, custom-logo, food-and-drink, e-commerce, blog, wide-blocks, custom-colors
Requires at least: 5.6
Tested up to: 7.0
Requires PHP: 7.2
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Stable tag: 1.2.8

== Description ==

The Pastry Shop Theme offers a charming and adaptable solution for businesses in the bakery and cake shop industries, enabling them to showcase their delicious creations online with professionalism. It's ideal for bakeries that want to feature artisanal breads and gourmet pastries while also catering to cake designers who specialize in wedding and celebration cakes. Confectioneries and chocolatiers can prominently display their handcrafted chocolates and seasonal treats, while sweet shops benefit from dedicated sections for signature desserts and gift boxes. Dessert cafés and patisseries can utilize the theme to present elegant menu offerings and seasonal pastry collections. Artisan bread makers can highlight their specialty loaves with quality images and detailed descriptions. With features like integrated online ordering, flexible layout customization, and options for product galleries, this theme supports seamless eCommerce, subscription boxes, and dessert catering. Enhanced with interactive menus and dedicated spaces for gluten-free or vegan treats, it also ensures that your restaurant or café stands out through responsive design and SEO optimization, helping your food business reach a broader audience and thrive online.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your Pastry Shop right away.

== Changelog ==

= 1.2.8 =
* Minor Improvements and Fixes and Fixed Styling Issues.

= 1.2.7 =
* Fixed Styling Issues and UI and UX Improvements.

= 1.2.6 =
* Stability and Performance Enhancements.

= 1.2.5 - June 11 2026 =

* Updated get started.
* Resolved css for button in customizer.
* Tested upto 7.0

= 1.2.4 =

* Fixed Minor Issues.

= 1.2.3 - May 16 2026 =

* Updated getstarted.
* Updated language folder.
* Updated getstarted notice.

= 1.1.7 - January 8 2026 =

* Added progress bar.
* Updtaed rtl.css file.
* Added menu in demo import.
* Fetching post in blog page.
* Resolve error of services section.
* Resolve tgm plugin error.

= 1.1.6 - December 31 2025 =

* Fixed minor error.

= 1.1.5 - December 11 2025 =

* Added sticky copyright.
* Added premium buttons in site identity section, footer section and header section.
* Tested upto 6.9.

= 1.1.4 - December 1 2025 =

* Resolved minor css bug.

= 1.1.3 - November 10 2025 =

* Added site aniamtion.

= 1.1.2 - November 1 2025 =

* Fixed minor errors.

= 1.1.1 - October 15 2025 =

* Fixed minor errors.
* Updated rtl css.

= 1.1 - October 1 2025 =

* Fixed minor errors.

= 1.0.9 - September 17 2025 =

* Added wide blocks
* Added custom colors

= 1.0.8 - September 2 2025 =

* Fixed minor issues.

= 1.0.7 - August 7 2025 =

* Resolved minor css issues.

= 1.0.6 - July 8 2025 =

* Updated woocommerce template.
* Added default header content.

= 1.0.5 - June 9 2025 =

* Added preloader background image option.
* Added first capital letter option for post.

= 1.0.4 - May 26 2025 =

* Updated getstarted notice.
* Added metabox seprator.

= 1.0.3 - May 6 2025 =

* Updated theme sidebar.
* Updated footer widget css.
* Added css for pagination.
* Updated rtl css.

= 1.0.2 - April 25 2025 =

* Added scroll to top progress bar.
* Resolved init function error.
* Tested upto 6.8

= 1.0.1 - April 17 2025 =

* Added enable related post option.
* Added enable related post image option.

= 0.9 - March 29 2025 =

* Added site title font size setting.
* Added site tagline font size setting.
* Added site title color option.

= 0.8 - March 13 2025 =

* Added no result page title setting.
* Added no result page text setting.
* Updated woocommerce.

= 0.7 - February 19 2025  =

* Added related post.

= 0.6 - January 28 2025 =

* Added enable post navigation option.
* Resolved css issue for post navigation.

= 0.5 - January 4 2024 =

* Added footer copyright background color.
* Added footer copyright text color.

= 0.4 - December 24 2024 =

* Fixed the translation issue in the "getting-started.php" and "free-vs-pro-panel.php" file.
* Resolved css issue for shop page.

= 0.3 - December 16 2024 =

* Added cursor dot outline.
* Added theme color setting.
* Added typography setting.
* Added footer link.
* Added plugins.json file.

= 0.2 - December 4 2024 =

* Removed prefix from the handle name on wp_enqueue_style for font awesome.
* Resolved image alignment issue.
* Updated woocommerce.

= 0.1 - November 14 2024 =

* Initial release

== Copyright ==

Pastry Shop WordPress Theme, Copyright 2015-2024 mizanthemes.com
Pastry Shop distributed under the terms of the GNU General Public License v3

== Credits ==

* Based on Underscores http://underscores.me/, (C) 2012-2016 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)

* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2015 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)

* Font Awesome: http://fontawesome.io/, (c) Dave Gandy, CSS - [MIT](http://opensource.org/licenses/MIT) ; Fonts -SIL OFL 1.1, Code: MIT License

* Superfish https://github.com/joeldbirch/superfish.git, Copyright 2013, Justin Tadlock ,MIT license. v1.7.9(https://github.com/joeldbirch/superfish/blob/master/MIT-LICENSE.txt)

* Bootstrap https://github.com/twbs/bootstrap/releases/tag/v5.3.3/bootstrap-5.3.3-dist.zip ,copyright 2011-2024, Mark Otto , MIT License ( https://github.com/twbs/bootstrap/blob/main/LICENSE )

* PHP files https://raw.githubusercontent.com/WPTT/font-loader/master/wptt-webfont-loader.php ,WPTT_WebFont_Loader( https://opensource.org/licenses/MIT)

* TGMPA GaryJones Copyright (C) 1989, 1991, https://github.com/TGMPA/TGM-Plugin-Activation/blob/develop/LICENSE.md, License: GNU General Public License v2.0

== Images ==

* All images are licensed under [CC0](http://creativecommons.org/publicdomain/zero/1.0/legalcode.txt)

* https://pxhere.com/en/photo/956979
* https://pxhere.com/en/photo/1203028
* https://pxhere.com/en/photo/586234
* https://pxhere.com/en/photo/1556579
* https://pxhere.com/en/photo/903704